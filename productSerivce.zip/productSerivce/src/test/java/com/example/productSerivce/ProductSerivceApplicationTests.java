package com.example.productSerivce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductSerivceApplicationTests {

	@Test
	void contextLoads() {
	}

}
