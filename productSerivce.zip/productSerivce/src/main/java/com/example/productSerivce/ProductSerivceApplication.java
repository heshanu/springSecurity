package com.example.productSerivce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductSerivceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductSerivceApplication.class, args);
	}

}
